﻿using System;

namespace demo1
{
    class Program
    {
        static void Main(string[] args)
        {
           int age;//variable declaration
           age = 37;//initialization
           int num1 = 24;//declaration and initialization
           int a = 4,b = 3 ,c ;
          age = 40;
          int firstNume = 22;
          Console.WriteLine("Your age is " + age);//concatination
        }
    }
}
